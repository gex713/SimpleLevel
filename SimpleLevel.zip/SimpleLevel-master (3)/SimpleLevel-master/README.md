# SimpleLevel
Building a simple level for a platformer to get the basics of building a game with Unity. 
